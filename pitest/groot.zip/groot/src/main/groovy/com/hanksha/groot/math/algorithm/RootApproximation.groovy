package com.hanksha.groot.math.algorithm

import groovy.transform.Canonical

/**
 * Created by vivien on 8/20/16.
 */

@Canonical
class RootApproximation {

    public static MAX_NUM_ITER = 500

    double root

    List<Map> steps

}
